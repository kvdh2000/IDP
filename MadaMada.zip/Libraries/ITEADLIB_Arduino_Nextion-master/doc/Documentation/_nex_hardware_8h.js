var _nex_hardware_8h =
[
    [ "nexInit", "group___core_a_p_i.html#gab09ddba6b72334d30ae091a7b038d790", null ],
    [ "nexLoop", "group___core_a_p_i.html#ga91c549e696b0ca035cf18901e6a50d5a", null ]
];