/home/john/tools/astyle --style=allman *.h *.cpp
